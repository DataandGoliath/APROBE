print("LOADING DEPENDANCIES") #IDK about you but I get impatient when a program takes ages to load because it has 30,000 deps. 
try:
	import datetime
	import time as t
	import subprocess
	import random as r
	from os import system as sy
	from scapy.all import *
	from easygui import *
	import os
	import sys
	sy("clear")
except:
	#print("Looks like you fucked up! Installing dependancies.")
	print("Error! You're missing some dependancies. Installing...")
	sy("pip install scapy")
	sy("pip install easygui")
#GLOBALS
config="config.lcf"
def Banner(x):
	print("           _____  _____   ____  ____  ______ ")
	print("     /\   |  __ \|  __ \ / __ \|  _ \|  ____|")
	print("    /  \  | |__) | |__) | |  | | |_) | |__   ")
	print("   / /\ \ |  ___/|  _  /| |  | |  _ <|  __|  ")
	print("  / ____ \| |    | | \ \| |__| | |_) | |____ ")
	print(" /_/    \_\_|    |_|  \_\\\____/|____/|______|") #Damn escape backslash :(
	if x==1:
		print("       AN ANAL PROBE FOR YOUR COMPUTER       ")
		print("")
	else:
		print("\n")

#Get version information
#	config=file("config.lcf")
for line in config:
#	version="0"
	if "VERSION: " in line:
		version=line[9:].replace("\n","")
	version="1.0.0 ALPHA" #versionfinder is broken for now :(
def GetSomething(x): #BROKEN
	for line in config:
		if x in line:
			result=line.split(":",1)
			return str(result)
			break
Banner(1)
#Get # of vulnerabilities
path,dirs,files=os.walk("vulnsdb").next()
vulns=0
for i in files:
	if i[-3:]==".py" or i[-4:]==".apm":
		vulns=vulns+1
vulns=str(vulns)
#Begin working
print("VERSION: "+version)
print("INDEXED VULNERABILITIES: "+vulns)
if vulns=="0":
	print("WARNING: NO INDEXED VULNERABILITIES DETECTED. SCANS WILL BE INEFFECTIVE.")
host=raw_input("HOSTNAME/IP > ")
print("\nBEGINNING VULNERABILITY SCAN.")
reportfile="reports/"+host+".rpt"
open(reportfile,"w+")
f=open(reportfile,"a")
f.write("HOST: "+host)
#f.write("DATE AND TIME: "+
now=str(datetime.now())
f.write("\nDATE AND TIME: "+now)
f.write("\nSCAN BEGIN.\n\n")
f.close()
def vulnscan():
	vulnernum=0
	print("Engaging host.")
	for i in os.listdir('vulnsdb'):
		if i[-4:] ==".apm" or i[-3:] ==".py":
			module="vulnsdb/"+i
			proc = subprocess.Popen(['python', module, host], stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
			output = proc.communicate()[0]
			if "is vulnerable" in output:
				vulnernum=vulnernum+1
				print output
				f=open(reportfile,"a")
				f.write(output)
				f.close()
			elif "is not vulnerable" in output:
				f=open(reportfile,"a")
				f.write(output)
				f.close()
	print("Scan complete.")
	if vulnernum==1:
		print("Target is potentially vulnerable to 1 exploit.")
		f=open(reportfile,"a")
		f.write("\nSUMMARY:\nTarget is potentially vulnerable to 1 exploit.\n")
		f.close()
	else:
		print("Target is potentially vulnerable to "+str(vulnernum)+" exploits.")
		f=open(reportfile,"a")
		f.write("\nSUMMARY:\nTarget is potentially vulnerable to "+str(vulnernum)+" exploits.\n")
		f.close()

print("Pinging to see if host is up...")
resp=sr(IP(dst=host)/ICMP(),retry=0,timeout=1,verbose=False)
if "ICMP:1" in str(resp[0]):
	#print resp[0]
	print("Host is up. Beginning scan.")
	vulnscan()
else:
	print("Host is not accepting ping requests. This could mean the host is down. \nIf the host is known to be up, it may be refusing ping requests due to a firewall. We will circumvent this in later versions. For now, use \nnmap -Pn --script vulns "+host)
	sy("rm "+host+".rpt")
