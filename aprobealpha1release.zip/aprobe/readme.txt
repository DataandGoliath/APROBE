Welcome to AProbe.
AProbe, short for Anal Probe, is a vulnerability scanner for 32 AND 64 bit Kali Linux who's code is as crude as its language..
Because, well, I'm sick and tired of trying to get OpenVAS to work, Nessus and Nexpose and such only work on x64, and I use x32 goddamnit.
So, I've elected for a change of pace. I present, 
AProbe. 
Enjoy.
